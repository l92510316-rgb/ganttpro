<?php
declare(strict_types=1);

header('Content-Type: application/json; charset=utf-8');
header('Cache-Control: no-store, no-cache, must-revalidate, max-age=0');

$dataFile = __DIR__ . '/../data/ganttpro-data.json';

if (!is_file($dataFile)) {
    echo json_encode([
        'app' => 'ganttpro',
        'revision' => 0,
        'projects' => [],
        'message' => 'no data file'
    ], JSON_UNESCAPED_UNICODE);
    exit;
}

$fp = fopen($dataFile, 'rb');
if (!$fp) {
    http_response_code(500);
    echo json_encode(['ok' => false, 'error' => 'data file open failed'], JSON_UNESCAPED_UNICODE);
    exit;
}

flock($fp, LOCK_SH);
$json = stream_get_contents($fp);
flock($fp, LOCK_UN);
fclose($fp);

$decoded = json_decode($json ?: '', true);
if (!is_array($decoded)) {
    http_response_code(500);
    echo json_encode(['ok' => false, 'error' => 'invalid data json'], JSON_UNESCAPED_UNICODE);
    exit;
}

echo json_encode($decoded, JSON_UNESCAPED_UNICODE);
