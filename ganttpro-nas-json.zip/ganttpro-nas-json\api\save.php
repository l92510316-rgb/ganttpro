<?php
declare(strict_types=1);

header('Content-Type: application/json; charset=utf-8');
header('Cache-Control: no-store, no-cache, must-revalidate, max-age=0');

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    echo json_encode(['ok' => false, 'error' => 'POST only'], JSON_UNESCAPED_UNICODE);
    exit;
}

$dataDir = __DIR__ . '/../data';
$backupDir = __DIR__ . '/../backup';
$dataFile = $dataDir . '/ganttpro-data.json';
$lockFile = $dataDir . '/ganttpro-data.lock';

if (!is_dir($dataDir)) {
    mkdir($dataDir, 0775, true);
}
if (!is_dir($backupDir)) {
    mkdir($backupDir, 0775, true);
}

$raw = file_get_contents('php://input');
$input = json_decode($raw ?: '', true);
if (!is_array($input) || !isset($input['projects']) || !is_array($input['projects'])) {
    http_response_code(400);
    echo json_encode(['ok' => false, 'error' => 'invalid payload'], JSON_UNESCAPED_UNICODE);
    exit;
}

$lock = fopen($lockFile, 'c+');
if (!$lock) {
    http_response_code(500);
    echo json_encode(['ok' => false, 'error' => 'lock open failed'], JSON_UNESCAPED_UNICODE);
    exit;
}

flock($lock, LOCK_EX);

$currentRevision = 0;
$current = null;
if (is_file($dataFile)) {
    $currentRaw = file_get_contents($dataFile);
    $current = json_decode($currentRaw ?: '', true);
    if (is_array($current) && isset($current['revision'])) {
        $currentRevision = (int)$current['revision'];
    }
}

$baseRevision = isset($input['baseRevision']) ? (int)$input['baseRevision'] : $currentRevision;
if ($currentRevision > 0 && $baseRevision > 0 && $baseRevision !== $currentRevision) {
    flock($lock, LOCK_UN);
    fclose($lock);
    http_response_code(409);
    echo json_encode([
        'ok' => false,
        'error' => 'revision conflict',
        'revision' => $currentRevision
    ], JSON_UNESCAPED_UNICODE);
    exit;
}

if (is_file($dataFile)) {
    $backupName = $backupDir . '/ganttpro-data-' . date('Ymd-His') . '.json';
    @copy($dataFile, $backupName);
}

$nextRevision = $currentRevision + 1;
$payload = [
    'app' => 'ganttpro',
    'revision' => $nextRevision,
    'savedAt' => date('c'),
    'clientSavedAt' => $input['clientSavedAt'] ?? null,
    'reason' => $input['reason'] ?? 'save',
    'count' => count($input['projects']),
    'projects' => $input['projects'],
];

$json = json_encode($payload, JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT);
if ($json === false || file_put_contents($dataFile, $json, LOCK_EX) === false) {
    flock($lock, LOCK_UN);
    fclose($lock);
    http_response_code(500);
    echo json_encode(['ok' => false, 'error' => 'data write failed'], JSON_UNESCAPED_UNICODE);
    exit;
}

flock($lock, LOCK_UN);
fclose($lock);

echo json_encode([
    'ok' => true,
    'revision' => $nextRevision,
    'savedAt' => $payload['savedAt'],
    'count' => $payload['count'],
], JSON_UNESCAPED_UNICODE);
